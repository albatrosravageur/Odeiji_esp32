package ch.epfl.esl.sportstracker;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class NewEntreprisesActivity extends AppCompatActivity {

    private Profile userProfile = null;
    private ProgressDialog progressDialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        progressDialog= new ProgressDialog(this);
        setContentView(R.layout.activity_new_entrprise);
        final TextView username = findViewById(R.id.Username);
        Button button = findViewById(R.id.RegisterButton);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent intent = new Intent(NewEntreprisesActivity.this, MainActivity.class);

                progressDialog.setMessage("Registering user...");
                progressDialog.show();

                //Toast.makeText(getApplicationContext(), id_ent, Toast.LENGTH_LONG).show();

                StringRequest stringRequest2 = new StringRequest(Request.Method.POST,
                        Constants.URL_REGISTER_ENTREPRISE,
                        new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                                progressDialog.dismiss();

                                try {
                                    JSONObject jsonObject = new JSONObject(response);

                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                            }
                        },
                        new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                progressDialog.hide();
                                Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_LONG).show();
                            }
                        }) {
                    @Override
                    protected Map<String, String> getParams() throws AuthFailureError {
                        Map<String, String> params = new HashMap<>();
                        params.put("Name", username.getText().toString().trim());
                        return params;
                    }
                };


                RequestHandler.getInstance(NewEntreprisesActivity.this).addToRequestQueue(stringRequest2);
                finish();
            }
        });
    }

}