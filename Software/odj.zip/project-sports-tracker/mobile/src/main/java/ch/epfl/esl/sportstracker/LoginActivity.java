package ch.epfl.esl.sportstracker;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class LoginActivity extends AppCompatActivity {

    private final String TAG = this.getClass().getSimpleName();
    HashMap<String,String> hashMap = new HashMap<>();

    private static final int REGISTER_PROFILE = 1;

    private Profile userProfile = null;
    private ProgressDialog progressDialog;
    HttpParse httpParse = new HttpParse();
    String finalResult;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Please wait...");





        Log.v(TAG, "Hello world!");

        Button rButton = findViewById(R.id.RegisterButton);
        rButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentEditProfile = new Intent(LoginActivity.this, EditProfileActivity
                        .class);
                /*if (userProfile != null) {
                    intentEditProfile.putExtra(MyProfileFragment.USER_PROFILE, userProfile);
                }*/
                startActivityForResult(intentEditProfile, REGISTER_PROFILE);
            }
        });
    }

    private void userLogin(){
        TextView editTextUsername = findViewById(R.id.username);
        TextView editTextPassword = findViewById(R.id.password);
        final String username = editTextUsername.getText().toString().trim();
        final String password = editTextPassword.getText().toString().trim();

        progressDialog.show();

        StringRequest stringRequest = new StringRequest(
                Request.Method.POST,
                Constants.URL_LOGIN,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        progressDialog.dismiss();
                        try {
                            JSONObject obj = new JSONObject(response);
                            if(!obj.getBoolean("error")){
                                SharedPrefManager.getInstance(getApplicationContext())
                                        .userLogin(
                                                obj.getInt("id"),
                                                obj.getString("username"),
                                                obj.getString("email")
                                        );
                                Toast.makeText(
                                        getApplicationContext(),
                                        "User Login Successful",
                                        Toast.LENGTH_LONG
                                ).show();
                            }else{
                                Toast.makeText(
                                        getApplicationContext(),
                                        obj.getString("message"),
                                        Toast.LENGTH_LONG
                                ).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        progressDialog.dismiss();

                        Toast.makeText(
                                getApplicationContext(),
                                error.getMessage(),
                                Toast.LENGTH_LONG
                        ).show();
                    }
                }
        ){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("username", username);
                params.put("password", password);
                return params;
            }

        };

        RequestHandler.getInstance(this).addToRequestQueue(stringRequest);
    }

    public void clickedLoginButtonXmlCallback(View view) {
        TextView mTextView = findViewById(R.id.LoginMessage);
        //userLogin();

        TextView editTextUsername = findViewById(R.id.username);
        TextView editTextPassword = findViewById(R.id.password);
        final String username = editTextUsername.getText().toString().trim();
        final String password = editTextPassword.getText().toString().trim();


        UserLoginFunction(username, password);
       /* if (userProfile != null) {
            Intent intent = new Intent(LoginActivity.this, MainActivity.class);
            intent.putExtra(MyProfileFragment.USER_PROFILE, userProfile);
            startActivity(intent);
        } else {
            mTextView.setText(R.string.not_registered_yet);
            mTextView.setTextColor(Color.RED);
        }*/
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REGISTER_PROFILE && resultCode == RESULT_OK && data != null) {
            userProfile = (Profile) data.getSerializableExtra(MyProfileFragment.USER_PROFILE);
            if (userProfile != null) {
                TextView username = findViewById(R.id.username);
                username.setText(userProfile.username);
                TextView password = findViewById(R.id.password);
                password.setText(userProfile.password);
            }
        }
    }
    public void UserLoginFunction(final String username, final String password) {

        class UserLoginClass extends AsyncTask<String, Void, String> {

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                //Toast.makeText(LoginActivity.this, "cool", Toast.LENGTH_LONG).show();
                //progressDialog = ProgressDialog.show(getApplicationContext(), "Loading Data", null, true, true);
            }

            @Override
            protected void onPostExecute(String httpResponseMsg) {

                super.onPostExecute(httpResponseMsg);

               // progressDialog.dismiss();

                if (httpResponseMsg.equalsIgnoreCase("Data Matched")) {

                    finish();

                    Intent intent = new Intent(LoginActivity.this, MainActivity.class);

                    intent.putExtra("username", username);

                    startActivity(intent);

                } else {

                    Toast.makeText(LoginActivity.this, httpResponseMsg, Toast.LENGTH_LONG).show();
                }

            }

            @Override
            protected String doInBackground(String... params) {

                hashMap.put("username", params[0]);

                hashMap.put("password", params[1]);

                finalResult = httpParse.postRequest(hashMap, Constants.URL_LOGIN);

                return finalResult;
            }


        }
        UserLoginClass userLoginClass = new UserLoginClass();

        userLoginClass.execute(username,password);
    }
}
