package ch.epfl.esl.sportstracker;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class Settings extends AppCompatActivity {
    private Profile userProfile = null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_profile);
        Intent intent = getIntent();
        userProfile= (Profile) intent.getSerializableExtra(MyProfileFragment.USER_PROFILE);
        //userProfile = (Profile) savedInstanceState.getSerializable(MyProfileFragment.USER_PROFILE);
        Toast.makeText(getApplicationContext(), userProfile.username, Toast.LENGTH_LONG).show();

    }
}
