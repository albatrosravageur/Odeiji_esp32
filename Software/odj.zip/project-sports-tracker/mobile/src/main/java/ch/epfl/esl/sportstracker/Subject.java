package ch.epfl.esl.sportstracker;

public class Subject {

    int time;
    String name;
    String id;

    public Subject( String name, int time, String id) {
        this.name = name;
        this.time = time;
        this.id = id;
    }

    public int getTime() {
        return time;
    }

    public String getName() {
        return name;
    }
    public String getId() {
        return id;
    }

}
