package ch.epfl.esl.sportstracker;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

public class EditProfileActivity extends AppCompatActivity {

    private final String TAG = this.getClass().getSimpleName();

    private static final int PICK_IMAGE = 1;
    private File imageFile;
    private Profile userProfile;
    private CheckBox check;
    private ProgressDialog progressDialog;
    boolean CGUcheck=false;
    private  String token ;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);
        progressDialog= new ProgressDialog(this);


        /*if (token == null) {
            progressDialog.dismiss();
            Toast.makeText(this, "Token not generated", Toast.LENGTH_LONG).show();
            return;
        }*/

        Intent intent = getIntent();
        userProfile = (Profile) intent.getSerializableExtra(MyProfileFragment.USER_PROFILE);
        if (userProfile != null) {
            setProfileToEdit();
        }
        check=findViewById(R.id.checkBox);

        String text = "I accept CGU";

        Spannable ss =  new SpannableString(text);

        ClickableSpan clickableSpan = new ClickableSpan() {
            @Override
            public void onClick(@NonNull View view) {
                Intent intentCGU = new Intent(EditProfileActivity.this, CGU.class);
                startActivity(intentCGU);
            }
        };

        ss.setSpan(clickableSpan,9,12, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        check.setText(ss);
        check.setMovementMethod(LinkMovementMethod.getInstance());

        check.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(check.isChecked()){
                    CGUcheck=true;
                }
                else{
                    CGUcheck=false;
                }
            }
        });

        FirebaseInstanceId.getInstance().getInstanceId()
                .addOnCompleteListener(new OnCompleteListener<InstanceIdResult>() {
                    @Override
                    public void onComplete(@NonNull Task<InstanceIdResult> task) {
                        if (!task.isSuccessful()) {
                            Log.w(TAG, "getInstanceId failed", task.getException());
                            return;
                        }

                        // Get new Instance ID token
                        token = task.getResult().getToken();

                        // Log and toast
                        //String msg = getString(R.string.msg_token_fmt, token);
                        //Log.d(TAG, msg);
                        //Toast.makeText(EditProfileActivity.this, token, Toast.LENGTH_SHORT).show();
                    }
                });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_edit_profile, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_clear:
                clearUser();
                break;
            case R.id.action_validate:
                editUser();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    private void clearUser() {
        ImageView userImageView = findViewById(R.id.userImage);
        TextView usernameTextView = findViewById(R.id.editUsername);
        TextView passwordTextView = findViewById(R.id.editPassword);
        TextView MailTextView = findViewById(R.id.editMail);

        userImageView.setImageDrawable(null);
        usernameTextView.setText("");
        passwordTextView.setText("");
        MailTextView.setText("");
    }

    private void setProfileToEdit() {

        ImageView userImageView = findViewById(R.id.userImage);
        TextView usernameTextView = findViewById(R.id.editUsername);
        TextView passwordTextView = findViewById(R.id.editPassword);
        TextView MailTextView = findViewById(R.id.editMail);


        final InputStream imageStream;
        try {
            imageStream = new FileInputStream(userProfile.photoPath);
            final Bitmap selectedImage = BitmapFactory.decodeStream(imageStream);
            userImageView.setImageBitmap(selectedImage);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        usernameTextView.setText(userProfile.username);
        passwordTextView.setText(userProfile.password);
        MailTextView.setText(userProfile.mail);

    }

    public void chooseImage(View view) {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE);
    }

    private void editUser() {
        if(CGUcheck) {
            TextView username = findViewById(R.id.editUsername);
            TextView password = findViewById(R.id.editPassword);
            TextView email = findViewById(R.id.editMail);
            userProfile = new Profile(username.getText().toString(), password.getText().toString());
            userProfile.entreprises_id="1";

            final String mail = email.getText().toString().trim();
            final String user = username.getText().toString().trim();
            final String pass = password.getText().toString().trim();

            progressDialog.setMessage("Registering user...");
            progressDialog.show();

            //final String token = SharedPreference.getInstance(this).getDeviceToken();

            //Toast.makeText(getApplicationContext(), token, Toast.LENGTH_LONG).show();

            StringRequest stringRequest = new StringRequest(Request.Method.POST,
                    Constants.URL_REGISTER,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            progressDialog.dismiss();

                            try {
                                JSONObject jsonObject = new JSONObject(response);

                                //Toast.makeText(getApplicationContext(), jsonObject.getString("message"), Toast.LENGTH_LONG).show();
                                userProfile.id=jsonObject.getString("id");

                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            progressDialog.hide();
                            //Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_LONG).show();
                        }
                    }) {
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    Map<String, String> params = new HashMap<>();
                    params.put("username", user);
                    params.put("email", mail);
                    params.put("token", token);
                    params.put("password", pass);
                    return params;
                }
            };


            FcmVolley.getInstance(this).addToRequestQueue(stringRequest);
            //Toast.makeText(getApplicationContext(), userProfile.id, Toast.LENGTH_LONG).show();





            TextView lemail = findViewById(R.id.editMail);
            try {
                userProfile.mail = lemail.getText().toString();
            } catch (NumberFormatException e) {
                userProfile.mail = "";
            }
            if (imageFile == null) {
                userProfile.photoPath = "";
            } else {
                userProfile.photoPath = imageFile.getPath();
            }

            //Now we go back to LoginActivity, later this activity can be used
            // also to edit the profile without going back to LoginActivity
            // (there will be an if)
            Intent intent = new Intent(EditProfileActivity.this, LoginActivity.class);
            intent.putExtra(MyProfileFragment.USER_PROFILE, userProfile);
            setResult(AppCompatActivity.RESULT_OK, intent);
            finish();
        }
        else {
            Context context = getApplicationContext();
            CharSequence text = "You have to accept CGU";
            int duration = Toast.LENGTH_SHORT;

            Toast toast = Toast.makeText(context, text, duration);
            toast.show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE && resultCode == RESULT_OK) {
            Uri imageUri = data.getData();
            imageFile = new File(getExternalFilesDir(null), "profileImage");
            try {
                copyImage(imageUri, imageFile);
            } catch (IOException e) {
                e.printStackTrace();
            }
            final InputStream imageStream;
            try {
                imageStream = getContentResolver().openInputStream(Uri.fromFile(imageFile));
                final Bitmap selectedImage = BitmapFactory.decodeStream(imageStream);
                ImageView imageView = findViewById(R.id.userImage);
                imageView.setImageBitmap(selectedImage);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }
    }

    private void copyImage(Uri uriInput, File fileOutput) throws IOException {
        InputStream in = null;
        OutputStream out = null;

        try {
            in = getContentResolver().openInputStream(uriInput);
            out = new FileOutputStream(fileOutput);
            // Transfer bytes from in to out
            byte[] buf = new byte[1024];
            int len;
            while ((len = in.read(buf)) > 0) {
                out.write(buf, 0, len);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            in.close();
            out.close();
        }
    }
}
