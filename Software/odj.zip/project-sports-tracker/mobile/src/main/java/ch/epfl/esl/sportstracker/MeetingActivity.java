package ch.epfl.esl.sportstracker;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Toolbar;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import it.xabaras.android.recyclerview.swipedecorator.RecyclerViewSwipeDecorator;

public class MeetingActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    MeetingAdapter recyclerAdapter;
    int play=1;
    private String id_ent;
    private static final int REGISTER_PROFILE = 1;
    private Profile userProfile = null;

    List<Meeting> moviesList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_meeting);
        Intent intent = getIntent();
        userProfile= (Profile) intent.getSerializableExtra(MyProfileFragment.USER_PROFILE);
        //userProfile = (Profile) savedInstanceState.getSerializable(MyProfileFragment.USER_PROFILE);
        Toast.makeText(getApplicationContext(), userProfile.username, Toast.LENGTH_LONG).show();

        moviesList = new ArrayList<>();
        recyclerView = findViewById(R.id.recyclerView);


        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_arrow_back_black_24dp);// set drawable icon
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        // getActionBar().setDisplayShowHomeEnabled( true ); // In your onCreate() or wherever.

        //getSupportActionBar().setHomeAsUpIndicator( R.drawable.ic_arrow_back_black_24dp);

        //recyclerAdapter = new MeetingAdapter(moviesList);
//        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        //recyclerView.setAdapter(recyclerAdapter);


        loadProducts();

        DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(this, DividerItemDecoration.VERTICAL);
        recyclerView.addItemDecoration(dividerItemDecoration);

        ItemTouchHelper itemTouchHelper = new ItemTouchHelper(simpleCallback);
        itemTouchHelper.attachToRecyclerView(recyclerView);



    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_refresh:
                // User chose the "Settings" item, show the app settings UI...
                Intent intentEditProfile = new Intent(MeetingActivity.this, NewMeetingActivity.class);
                intentEditProfile.putExtra(MyProfileFragment.USER_PROFILE, userProfile);
                startActivityForResult(intentEditProfile,REGISTER_PROFILE);
                return true;

            case R.id.home:
                // User chose the "Settings" item, show the app settings UI...
                return true;

            default:
                // If we got here, the user's action was not recognized.
                // Invoke the superclass to handle it.
                return super.onOptionsItemSelected(item);

        }
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_manage_meeting, menu);
        return true;
    }

    String deletedMovie = null;
    int deletedTime = 0;

    ItemTouchHelper.SimpleCallback simpleCallback = new ItemTouchHelper.SimpleCallback(ItemTouchHelper.UP | ItemTouchHelper.DOWN | ItemTouchHelper.START | ItemTouchHelper.END,  ItemTouchHelper.LEFT) {
        @Override
        public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {

            int fromPosition = viewHolder.getAdapterPosition();
            int toPosition = target.getAdapterPosition();
            Collections.swap(moviesList, fromPosition, toPosition);
            recyclerView.getAdapter().notifyItemMoved(fromPosition, toPosition);
            return false;
        }

        @Override
        public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {

            final int position = viewHolder.getAdapterPosition();

            switch (direction){
                case ItemTouchHelper.LEFT:
                    deletedMovie =moviesList.get(position).getName();
                    //deletedTime =moviesList.get(position).getTime();
                    moviesList.remove(position);
                    recyclerAdapter.notifyItemRemoved(position);
                    /*Snackbar.make(recyclerView,deletedMovie, Snackbar.LENGTH_LONG).setAction("Undo", new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            moviesList.add(new Subject(deletedMovie,deletedTime));
                            recyclerAdapter.notifyItemInserted(position);
                        }
                    }).show();*/
                    break;

                case ItemTouchHelper.RIGHT:

                    break;
            }

        }

        @Override
        public void onChildDraw(@NonNull Canvas c, @NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, float dX, float dY, int actionState, boolean isCurrentlyActive) {

            new RecyclerViewSwipeDecorator.Builder(c, recyclerView, viewHolder, dX, dY, actionState, isCurrentlyActive)
                    .addSwipeLeftBackgroundColor(ContextCompat.getColor(MeetingActivity.this,R.color.colorAccent))
                    .addSwipeLeftActionIcon(R.drawable.ic_delete_black_24dp)
                    .create()
                    .decorate();

            super.onChildDraw(c, recyclerView, viewHolder, dX, dY, actionState, isCurrentlyActive);
        }
    };

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REGISTER_PROFILE && resultCode == RESULT_OK) {
            String dat = data.getStringExtra("userProfile");
            /*if (dat != null) {
                moviesList.add(new Meeting(dat));
            }*/

            recyclerAdapter.notifyDataSetChanged();
        }
    }
    private void loadProducts() {

        /*
         * Creating a String Request
         * The request type is GET defined by first parameter
         * The URL is defined in the second parameter
         * Then we have a Response Listener and a Error Listener
         * In response listener we will get the JSON response as a String
         * */
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Constants.URL_FIND_MEETINGS,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            //converting the string to json array object
                            JSONArray array = new JSONArray(response);

                            //traversing through all the object
                            for (int i = 0; i < array.length(); i++) {

                                //getting product object from json array
                                JSONObject product = array.getJSONObject(i);

                                //adding the product to product list
                                moviesList.add(new Meeting(
                                        product.getString("Name"),product.getString("id")
                                ));
                            }

                            //creating adapter object and setting it to recyclerview
                            //MeetingAdapter adapter = new MeetingAdapter(moviesList);
                            //recyclerView.setAdapter(adapter);
                            recyclerAdapter = new MeetingAdapter(moviesList);
                            //        recyclerView.setLayoutManager(new LinearLayoutManager(this));
                            recyclerView.setAdapter(recyclerAdapter);

                            recyclerAdapter.setOnItemClickListener(new MeetingAdapter.OnItemClickListener() {
                                @Override
                                public void onItemClick(int position) {
                                    Intent intentf = new Intent(MeetingActivity.this,SubjectActivity.class);
                                    intentf.putExtra(MyProfileFragment.USER_PROFILE, userProfile);
                                    intentf.putExtra("id", moviesList.get(position).getId());
                                    startActivity(intentf);
                                }

                            });

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("Entreprises_id", userProfile.entreprises_id);
                return params;
            }
        };



        //adding our stringrequest to queue
        RequestHandler.getInstance(MeetingActivity.this).addToRequestQueue(stringRequest);
    }

}