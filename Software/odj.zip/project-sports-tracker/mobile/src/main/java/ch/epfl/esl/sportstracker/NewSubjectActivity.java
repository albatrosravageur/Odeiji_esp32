package ch.epfl.esl.sportstracker;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class NewSubjectActivity extends AppCompatActivity {

    String id_meet;
    private Profile userProfile = null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_subject);
        Intent intent = getIntent();
        id_meet= (String) intent.getSerializableExtra("id");
        userProfile= (Profile) intent.getSerializableExtra(MyProfileFragment.USER_PROFILE);
        //userProfile = (Profile) savedInstanceState.getSerializable(MyProfileFragment.USER_PROFILE);
        Toast.makeText(getApplicationContext(), userProfile.username, Toast.LENGTH_LONG).show();
        final TextView username = findViewById(R.id.Username);
        final TextView Time = findViewById(R.id.Password);
        Button button = findViewById(R.id.RegisterButton);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                StringRequest stringRequest2 = new StringRequest(Request.Method.POST,
                        Constants.URL_REGISTER_POINT,
                        new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {

                                try {
                                    JSONObject jsonObject = new JSONObject(response);

                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                            }
                        },
                        new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_LONG).show();
                            }
                        }) {
                    @Override
                    protected Map<String, String> getParams() throws AuthFailureError {
                        Map<String, String> params = new HashMap<>();
                        params.put("time", Time.getText().toString().trim());
                        params.put("subject", username.getText().toString().trim());
                        params.put("about", "nice");
                        params.put("meeting_id", id_meet);
                        return params;
                    }
                };


                RequestHandler.getInstance(NewSubjectActivity.this).addToRequestQueue(stringRequest2);
                finish();
            }
        });
    }
}

