package ch.epfl.esl.sportstracker;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class NewMeetingActivity extends AppCompatActivity {

    private Profile userProfile = null;
    private ProgressDialog progressDialog;
    private String id_ent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        progressDialog= new ProgressDialog(this);
        Intent intent = getIntent();
        userProfile= (Profile) intent.getSerializableExtra(MyProfileFragment.USER_PROFILE);
        //userProfile = (Profile) savedInstanceState.getSerializable(MyProfileFragment.USER_PROFILE);
        Toast.makeText(getApplicationContext(), userProfile.username, Toast.LENGTH_LONG).show();

        StringRequest stringRequest = new StringRequest(Request.Method.POST,
                Constants.URL_FIND_ENTREPRISE,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        progressDialog.dismiss();

                        try {
                            JSONObject jsonObject = new JSONObject(response);


                            //Toast.makeText(getApplicationContext(), jsonObject.getString("Entreprises_id"), Toast.LENGTH_LONG).show();
                            id_ent=jsonObject.getString("Entreprises_id");
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        progressDialog.hide();
                        Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_LONG).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("username", userProfile.username);
                return params;
            }
        };
        RequestHandler.getInstance(NewMeetingActivity.this).addToRequestQueue(stringRequest);



        setContentView(R.layout.activity_new_meeting);
        final TextView username = findViewById(R.id.Username);
        final TextView Date = findViewById(R.id.Date);
        Button button = findViewById(R.id.RegisterButton);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent intent = new Intent(NewMeetingActivity.this, MeetingActivity.class);
                //intent.putExtra("userProfile", username.getText().toString());
                //setResult(AppCompatActivity.RESULT_OK, intent);

                final String date = Date.getText().toString().trim();
                final String user = username.getText().toString().trim();


                progressDialog.setMessage("Registering user...");
                progressDialog.show();

                //Toast.makeText(getApplicationContext(), id_ent, Toast.LENGTH_LONG).show();

                StringRequest stringRequest2 = new StringRequest(Request.Method.POST,
                        Constants.URL_REGISTER_MEETING,
                        new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                                progressDialog.dismiss();

                                try {
                                    JSONObject jsonObject = new JSONObject(response);

                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                            }
                        },
                        new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                progressDialog.hide();
                                Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_LONG).show();
                            }
                        }) {
                    @Override
                    protected Map<String, String> getParams() throws AuthFailureError {
                        Map<String, String> params = new HashMap<>();
                        params.put("name", user);
                        params.put("date", date);
                        params.put("desc", "nice");
                        params.put("Entreprises_id", id_ent);
                        return params;
                    }
                };


                RequestHandler.getInstance(NewMeetingActivity.this).addToRequestQueue(stringRequest2);
                finish();
            }
        });
    }
}