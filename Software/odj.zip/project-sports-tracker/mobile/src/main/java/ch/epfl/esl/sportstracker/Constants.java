package ch.epfl.esl.sportstracker;

public class Constants {

    private static final String ROOT_URL = "http://10.0.2.2/Android/v1/";
    public static final String URL_REGISTER = ROOT_URL+"registerUser.php";
    public static final String URL_LOGIN = ROOT_URL+"userLogin.php";
    public static final String URL_PRODUCTS = ROOT_URL+"findEntreprises.php";
    public static final String URL_CHANGE = ROOT_URL+"changeEntreprise.php";
    public static final String URL_FIND_ENTREPRISE = ROOT_URL+"findEntrepriseofuser.php";
    public static final String URL_REGISTER_MEETING = ROOT_URL+"registerMeeting.php";
    public static final String URL_REGISTER_ENTREPRISE = ROOT_URL+"registerEntreprise.php";
    public static final String URL_REGISTER_POINT = ROOT_URL+"registerPoint.php";
    public static final String URL_FIND_MEETINGS = ROOT_URL+"findMeetings.php";
    public static final String URL_FIND_POINTS = ROOT_URL+"findPoints.php";
    public static final String URL_SEND_SINGLE_PUSH = ROOT_URL+"sendSinglePush.php";
    public static final String URL_SEND_MULTIPLE_PUSH = ROOT_URL+"sendMultiplePush.php";
    public static final String URL_NOTIFY_MEETING = ROOT_URL+"sendPushtoEmployeesEntreprise.php";
    public static final String URL_ID_USER = ROOT_URL+"findidofUser.php";
    public static final String URL_USER = ROOT_URL+"findUser.php";
}
