package ch.epfl.esl.sportstracker;

import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.GridLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.viewpager.widget.ViewPager;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class MainActivity extends AppCompatActivity {

    GridLayout mainGrid;
    private Profile userProfile;
    private static final int BT_ENABLE = 1;
    private static final int REGISTER_PROFILE = 1;
    private static final int REGISTER_BLUETOOOTH = 2;
    private String username;
    BluetoothDevice device;

    private String mDeviceUUID;
    //private BluetoothSocket mBTSocket;
    private int mMaxChars ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        /*Intent intent = getIntent();
        userProfile= (Profile) intent.getSerializableExtra(MyProfileFragment.USER_PROFILE);
        //userProfile = (Profile) savedInstanceState.getSerializable(MyProfileFragment.USER_PROFILE);
        Toast.makeText(getApplicationContext(), userProfile.username, Toast.LENGTH_LONG).show();*/
        Intent intent = getIntent();
        username= intent.getStringExtra("username");
        //userProfile.username=username;

        //Toast.makeText(getApplicationContext(), username, Toast.LENGTH_LONG).show();


        StringRequest stringRequest = new StringRequest(Request.Method.POST, Constants.URL_USER,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            //converting the string to json array object
                            JSONObject jsonObject = new JSONObject(response);

                            //Toast.makeText(getApplicationContext(), jsonObject.getString("message"), Toast.LENGTH_LONG).show();
                            userProfile = new Profile(username, jsonObject.getString("password"));
                            userProfile.id=jsonObject.getString("id");
                            userProfile.entreprises_id=jsonObject.getString("Entreprises_id");
                            userProfile.mail=jsonObject.getString("email");

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        //progressDialog.hide();
                        Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_LONG).show();
                    }
                }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("username", username);
                return params;
            }
        };

        RequestHandler.getInstance(MainActivity.this).addToRequestQueue(stringRequest);

        mainGrid = (GridLayout) findViewById(R.id.mainGrid);

        //Set Event
        setSingleEvent(mainGrid);
        //setToggleEvent(mainGrid);

    }

    private void setToggleEvent(GridLayout mainGrid) {
        //Loop all child item of Main Grid
        for (int i = 0; i < mainGrid.getChildCount(); i++) {
            //You can see , all child item is CardView , so we just cast object to CardView
            final CardView cardView = (CardView) mainGrid.getChildAt(i);
            cardView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (cardView.getCardBackgroundColor().getDefaultColor() == -1) {
                        //Change background color
                        cardView.setCardBackgroundColor(Color.parseColor("#FF6F00"));
                        Toast.makeText(MainActivity.this, "State : True", Toast.LENGTH_SHORT).show();

                    } else {
                        //Change background color
                        cardView.setCardBackgroundColor(Color.parseColor("#FFFFFF"));
                        Toast.makeText(MainActivity.this, "State : False", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }
    }

    private void setSingleEvent(GridLayout mainGrid) {
        //Loop all child item of Main Grid
        for (int i = 0; i < mainGrid.getChildCount(); i++) {
            //You can see , all child item is CardView , so we just cast object to CardView
            CardView cardView = (CardView) mainGrid.getChildAt(i);
            final int finalI = i;
            cardView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    switch (finalI){
                        case 0:
                            //Toast.makeText(MainActivity.this, "bite", Toast.LENGTH_SHORT).show();
                            Intent intentf = new Intent(MainActivity.this,Connect.class);
                            intentf.putExtra(MyProfileFragment.USER_PROFILE, userProfile);
                            startActivityForResult(intentf, REGISTER_BLUETOOOTH);
                            //startActivity(intentf);
                            break;
                        case 1:
                            //Toast.makeText(MainActivity.this, "bite", Toast.LENGTH_SHORT).show();
                            Intent intentj= new Intent(MainActivity.this,MeetingActivity.class);
                            intentj.putExtra(MyProfileFragment.USER_PROFILE, userProfile);
                            startActivity(intentj);
                            break;
                        case 2:
                            //Toast.makeText(MainActivity.this, "bite", Toast.LENGTH_SHORT).show();
                            Intent intente = new Intent(MainActivity.this,EntreprisesActivity.class);
                            intente.putExtra(MyProfileFragment.USER_PROFILE, userProfile);
                            startActivity(intente);
                            break;
                        case 3:
                            //Toast.makeText(MainActivity.this, "bite", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(MainActivity.this,Settings.class);
                            intent.putExtra(MyProfileFragment.USER_PROFILE, userProfile);
                            startActivity(intent);
                            break;

                        case 4:
                            //Toast.makeText(MainActivity.this, "bi", Toast.LENGTH_SHORT).show();
                            Intent intenth = new Intent(MainActivity.this,Help.class);
                            intenth.putExtra(MyProfileFragment.USER_PROFILE, userProfile);
                            startActivity(intenth);
                            break;
                        case 5:
                            //Toast.makeText(MainActivity.this, "biche", Toast.LENGTH_SHORT).show();
                            Intent intentc = new Intent(MainActivity.this,Calendar.class);
                            intentc.putExtra(MyProfileFragment.USER_PROFILE, userProfile);
                            startActivity(intentc);
                            break;
                        default:
                            break;
                    }
                }
            });
        }
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REGISTER_PROFILE && data != null) {
            userProfile = (Profile) data.getSerializableExtra(MyProfileFragment.USER_PROFILE);
            Toast.makeText(getApplicationContext(), userProfile.username, Toast.LENGTH_LONG).show();
        }
        if (requestCode == REGISTER_BLUETOOOTH && data != null) {
            Bundle b = data.getExtras();
            device = b.getParcelable(Connect.DEVICE_EXTRA);
            mDeviceUUID = b.getString(Connect.DEVICE_UUID);
            mMaxChars = b.getInt(Connect.BUFFER_SIZE);

            Toast.makeText(getApplicationContext(), userProfile.username, Toast.LENGTH_LONG).show();

        }
    }
}
